﻿using Orchard.Environment.Extensions;

namespace Orchard.Tests.Extensions.ExtensionTypes {
    public class Alpha {
    }

    public class Beta {
    }

    [OrchardFeature("TestFeature")]
    public class Phi {
    }
}
