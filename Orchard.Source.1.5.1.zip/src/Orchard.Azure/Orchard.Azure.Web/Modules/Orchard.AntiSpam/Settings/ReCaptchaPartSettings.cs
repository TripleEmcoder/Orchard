﻿namespace Orchard.AntiSpam.Settings {
    public class ReCaptchaPartSettings {
        public string PublicKey { get; set; }
        public string PrivateKey { get; set; }
    }
}