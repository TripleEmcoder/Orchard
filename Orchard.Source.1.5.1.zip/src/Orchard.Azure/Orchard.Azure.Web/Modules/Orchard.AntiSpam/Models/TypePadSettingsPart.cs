﻿using Orchard.ContentManagement;

namespace Orchard.AntiSpam.Models {
    public class TypePadSettingsPart : ContentPart<TypePadSettingsPartRecord> {
    }
}