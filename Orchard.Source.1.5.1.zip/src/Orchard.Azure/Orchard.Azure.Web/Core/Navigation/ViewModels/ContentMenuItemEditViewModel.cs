using Orchard.Core.Navigation.Models;

namespace Orchard.Core.Navigation.ViewModels {
    public class ContentMenuItemEditViewModel  {
        public int ContentItemId { get; set; }
        public ContentMenuItemPart Part { get; set; }
    }
}