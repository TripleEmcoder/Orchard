﻿namespace Orchard.Core.Containers.Models {
    public enum OrderByDirection { 
        Ascending,
        Descending,
    }
}